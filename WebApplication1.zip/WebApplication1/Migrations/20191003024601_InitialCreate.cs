﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WebApplication1.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Wh",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    WhName = table.Column<string>(nullable: true),
                    Location = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Wh", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Wh_Storage",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    WhId = table.Column<int>(nullable: false),
                    StorageName = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Wh_Storage", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Wh_Storage_Wh_WhId",
                        column: x => x.WhId,
                        principalTable: "Wh",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Wh_Storage_Product",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Wh_StorageId = table.Column<int>(nullable: false),
                    ProductName = table.Column<string>(nullable: true),
                    Qty = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Wh_Storage_Product", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Wh_Storage_Product_Wh_Storage_Wh_StorageId",
                        column: x => x.Wh_StorageId,
                        principalTable: "Wh_Storage",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Wh_Storage_WhId",
                table: "Wh_Storage",
                column: "WhId");

            migrationBuilder.CreateIndex(
                name: "IX_Wh_Storage_Product_Wh_StorageId",
                table: "Wh_Storage_Product",
                column: "Wh_StorageId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Wh_Storage_Product");

            migrationBuilder.DropTable(
                name: "Wh_Storage");

            migrationBuilder.DropTable(
                name: "Wh");
        }
    }
}
