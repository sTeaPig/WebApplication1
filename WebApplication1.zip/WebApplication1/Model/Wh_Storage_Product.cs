﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Model
{
    public class Wh_Storage_Product
    {
        public int Id { get; set; }
        public int Wh_StorageId { get; set; }
        [DisplayName("產品名稱")]
        public string ProductName { get; set; }
        [DisplayName("數量")]
        public int Qty { get; set; }
        [DisplayName("儲位")]
        public Wh_Storage Wh_Storage { get; set; }
    }
}
