﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Model
{
    public class Wh_Storage
    {
        public int Id { get; set; }
        public int WhId { get; set; }
        [DisplayName("儲位名稱")]
        public string StorageName { get; set; }
        [DisplayName("倉庫")]
        public Wh Wh { get; set; }
        public List<Wh_Storage_Product> Wh_Storage_Product { get; set; }
    }
}
