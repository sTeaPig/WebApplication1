﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Model
{
    public class Wh
    {
        public int Id { get; set; }
        [DisplayName("倉庫名稱")]
        public string WhName { get; set; }
        [DisplayName("位置")]
        public string Location { get; set; }
        public List<Wh_Storage> Wh_Storage { get; set; }
    }
}
