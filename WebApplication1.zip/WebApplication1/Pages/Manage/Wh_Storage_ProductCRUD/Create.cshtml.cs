﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebApplication1.Model;
using WebApplication1.Models;

namespace WebApplication1.Pages.Manage.Wh_Storage_ProductCRUD
{
    public class CreateModel : PageModel
    {
        private readonly WebApplication1.Models.WebApplication1Context _context;

        public CreateModel(WebApplication1.Models.WebApplication1Context context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
        ViewData["Wh_StorageId"] = new SelectList(_context.Wh_Storage, "Id", "Id");
            return Page();
        }

        [BindProperty]
        public Wh_Storage_Product Wh_Storage_Product { get; set; }

        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Wh_Storage_Product.Add(Wh_Storage_Product);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
