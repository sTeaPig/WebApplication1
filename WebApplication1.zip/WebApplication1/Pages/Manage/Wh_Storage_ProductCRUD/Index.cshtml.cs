﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Model;
using WebApplication1.Models;

namespace WebApplication1.Pages.Manage.Wh_Storage_ProductCRUD
{
    public class IndexModel : PageModel
    {
        private readonly WebApplication1.Models.WebApplication1Context _context;

        public IndexModel(WebApplication1.Models.WebApplication1Context context)
        {
            _context = context;
        }

        public IList<Wh_Storage_Product> Wh_Storage_Product { get;set; }

        public async Task OnGetAsync()
        {
            Wh_Storage_Product = await _context.Wh_Storage_Product
                .Include(w => w.Wh_Storage).ToListAsync();
        }
    }
}
