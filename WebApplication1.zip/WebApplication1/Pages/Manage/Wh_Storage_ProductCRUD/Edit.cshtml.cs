﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Model;
using WebApplication1.Models;

namespace WebApplication1.Pages.Manage.Wh_Storage_ProductCRUD
{
    public class EditModel : PageModel
    {
        private readonly WebApplication1.Models.WebApplication1Context _context;

        public EditModel(WebApplication1.Models.WebApplication1Context context)
        {
            _context = context;
        }

        [BindProperty]
        public Wh_Storage_Product Wh_Storage_Product { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Wh_Storage_Product = await _context.Wh_Storage_Product
                .Include(w => w.Wh_Storage).FirstOrDefaultAsync(m => m.Id == id);

            if (Wh_Storage_Product == null)
            {
                return NotFound();
            }
           ViewData["Wh_StorageId"] = new SelectList(_context.Wh_Storage, "Id", "Id");
            return Page();
        }

        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(Wh_Storage_Product).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Wh_Storage_ProductExists(Wh_Storage_Product.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool Wh_Storage_ProductExists(int id)
        {
            return _context.Wh_Storage_Product.Any(e => e.Id == id);
        }
    }
}
