﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Model;
using WebApplication1.Models;

namespace WebApplication1.Pages.Manage.Wh_Storage_ProductCRUD
{
    public class DetailsModel : PageModel
    {
        private readonly WebApplication1.Models.WebApplication1Context _context;

        public DetailsModel(WebApplication1.Models.WebApplication1Context context)
        {
            _context = context;
        }

        public Wh_Storage_Product Wh_Storage_Product { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Wh_Storage_Product = await _context.Wh_Storage_Product
                .Include(w => w.Wh_Storage).FirstOrDefaultAsync(m => m.Id == id);

            if (Wh_Storage_Product == null)
            {
                return NotFound();
            }
            return Page();
        }
    }
}
