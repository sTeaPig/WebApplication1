﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Model;
using WebApplication1.Models;

namespace WebApplication1.Pages.Manage.Wh_StorageCRUD
{
    public class EditModel : PageModel
    {
        private readonly WebApplication1.Models.WebApplication1Context _context;

        public EditModel(WebApplication1.Models.WebApplication1Context context)
        {
            _context = context;
        }

        [BindProperty]
        public Wh_Storage Wh_Storage { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Wh_Storage = await _context.Wh_Storage
                .Include(w => w.Wh).FirstOrDefaultAsync(m => m.Id == id);

            if (Wh_Storage == null)
            {
                return NotFound();
            }
           ViewData["WhId"] = new SelectList(_context.Wh, "Id", "Id");
            return Page();
        }

        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(Wh_Storage).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Wh_StorageExists(Wh_Storage.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool Wh_StorageExists(int id)
        {
            return _context.Wh_Storage.Any(e => e.Id == id);
        }
    }
}
