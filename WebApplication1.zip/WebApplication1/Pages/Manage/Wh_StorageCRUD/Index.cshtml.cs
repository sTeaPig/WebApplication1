﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Model;
using WebApplication1.Models;

namespace WebApplication1.Pages.Manage.Wh_StorageCRUD
{
    public class IndexModel : PageModel
    {
        private readonly WebApplication1.Models.WebApplication1Context _context;

        public IndexModel(WebApplication1.Models.WebApplication1Context context)
        {
            _context = context;
        }

        public IList<Wh_Storage> Wh_Storage { get;set; }

        public async Task OnGetAsync()
        {
            Wh_Storage = await _context.Wh_Storage
                .Include(w => w.Wh).ToListAsync();
        }
    }
}
